<?php $__env->startSection('content'); ?>
<style>
    .gradient-text {
        /* font-size: 48px; */
        font-weight: bold;
        background: linear-gradient(to right, #aa5b22, #d18956, #A0522D, #F4A460);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    .gradient-button {
        font-weight: bold;
        color: white;
        padding: 10px 20px;
        background: linear-gradient(to right, #aa5b22, #d18956, #A0522D, #F4A460);
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .gradient-button:hover {
        background: linear-gradient(to right, #F4A460, #A0522D, #D2691E, #8B4513);
        color: #ffffff;
    }
</style>
    <section>
        <div class="page-header min-vh-100">
            <div class="container">
                <div class="row">
                    <!-- Login Form -->
                    <div class="col-xl-4 col-lg-5 col-md-6 d-flex flex-column mx-auto">
                        <div class="card card-plain mt-4 mb-2">
                            <div class="card-header pb-0 text-left bg-transparent">
                                <div class="row mb-3">
                                    
                                    <div class="col d-flex align-items-center">
                                        <h3 class="font-weight-bolder gradient-text">Dongworld</h3>
                                    </div>
                                </div>
                                <p class="mb-0" style="font-size: 15px">Enter your email and password to sign in</p>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('login')); ?>" role="form">
                                    <?php echo csrf_field(); ?>
                                    <label>Username</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Username" name="username" aria-label="Username" value="<?php echo e(old('username')); ?>" aria-describedby="username-addon">
                                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback text-xs" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <label>Password</label>
                                    <div class="mb-3">
                                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password" aria-label="Password" value="<?php echo e(old('password')); ?>" aria-describedby="password-addon">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback text-xs" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn gradient-button w-100 mt-4 mb-0">Sign in</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- End of  Login Form -->
                        <p class="text-secondary text-center">
                            Copyright © <script>
                                document.write(new Date().getFullYear())
                            </script> dongworld
                        </p>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lossscp/web/dongworld-admin.websiteku.space/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>