<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('./assets/img/logo.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('./assets/img/logo.png')); ?>">
    <title>
      Kopingumpul - Login
    </title>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- CSS Files -->
    <link id="pagestyle" href="../assets/css/soft-ui-dashboard.css?v=1.0.7" rel="stylesheet" />
  </head><?php /**PATH /home/lossscp/web/dongworld-admin.websiteku.space/public_html/resources/views/components/login-head.blade.php ENDPATH**/ ?>