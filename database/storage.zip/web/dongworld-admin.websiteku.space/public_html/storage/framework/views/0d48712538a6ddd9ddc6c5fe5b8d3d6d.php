<?php $__env->startSection('title'); ?>
    - Edit Episode
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="<?php echo e(route('series.index')); ?>">Series</a></li>
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="<?php echo e(route('episode.index', $series->id)); ?>">Episodes</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Edit Episode</li>
        </ol>
        <h5 class="font-weight-bolder mb-0">Episodes - <?php echo e($series->name); ?></h5>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header pb-0 px-3">
        <h5 class="mb-0">Edit Episode</h5>
    </div>
    <div class="card-body pt-4 p-3">
        <form action="<?php echo e(route('episode.update', [$series->id, $episode->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php if($series->type !== 'movie'): ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group has-validation">
                        <label for="episode_number" class="form-control-label">Episode Number</label>
                        <input class="form-control <?php $__errorArgs = ['episode_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger rounded-3 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" min="1" placeholder="1" name="episode_number" value="<?php echo e(old('episode_number', $episode->episode_number)); ?>" autofocus>
                        <?php $__errorArgs = ['episode_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group has-validation">
                        <label for="episode_number" class="form-control-label">Download Links</label>
<textarea
  class="form-control <?php $__errorArgs = ['download_links'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger rounded-3 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
  name="download_links"
  placeholder="https://link1
https://link2
https://link3"
  autofocus
><?php echo e(old('download_links', $downloadLinksValue)); ?></textarea>                        <?php $__errorArgs = ['download_links'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-12">
                    <label class="form-control-label">Links per Server (opsional)</label>
                </div>
                <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="form-group has-validation">
                        <label for="links[<?php echo e($srv->id); ?>]" class="form-control-label"><?php echo e($srv->name); ?></label>
                        <input class="form-control" type="text" name="links[<?php echo e($srv->id); ?>]" placeholder="https://..." value="<?php echo e(old('links.'.$srv->id, optional($links->get($srv->id))->url)); ?>">
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="d-flex justify-content-end">
                <button type="submit" class="btn bg-gradient-dark btn-md mt-4 mb-4">Simpan</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lossscp/web/dongworld-admin.websiteku.space/public_html/resources/views/admin/episode/edit.blade.php ENDPATH**/ ?>