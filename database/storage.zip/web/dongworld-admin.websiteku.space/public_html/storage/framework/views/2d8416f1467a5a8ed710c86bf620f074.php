<!--
=========================================================
* Soft UI Dashboard - v1.0.7
=========================================================

* Product Page: https://www.creative-tim.com/product/soft-ui-dashboard
* Copyright 2023 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://www.creative-tim.com/license)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <title>
    Dongworld Admin <?php echo $__env->yieldContent('title'); ?>
  </title>

  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="<?php echo e(asset('./assets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('./assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <link rel="preload" as="script" href="<?php echo e(asset('./assets/js/plugins/fontawesome.js')); ?>" crossorigin="anonymous">
    <script src="<?php echo e(asset('./assets/js/plugins/fontawesome.js')); ?>" defer crossorigin="anonymous"></script>
  <link href="<?php echo e(asset('./assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
  <!-- CSS Files -->
  <link id="pagestyle" href="<?php echo e(asset('./assets/css/soft-ui-dashboard.css?v=1.0.7')); ?>" rel="stylesheet" />

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

  
  <script src="<?php echo e(asset('assets/js/jquery-1.11.1.min.js')); ?>"
  crossorigin="anonymous"></script>

  <!-- Select2 CSS -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/css/select2.min.css" rel="stylesheet">

  <!-- Select2 JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/js/select2.min.js"></script>
  <style>
    .custom-hr {
      border: 0;
      height: 1px;
      background: #333;
      background-image: linear-gradient(to right, #8a8a8a, #333, #8a8a8a);
      margin: 10px 0;
    }
  </style>
</head>

<body class="g-sidenav-show  bg-gray-100">
  <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <?php echo $__env->make('components.admin-navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="container-fluid py-4">
      <?php echo $__env->yieldContent('content'); ?>
      <?php if (isset($component)) { $__componentOriginal563b6827cca32fa1a554dd261a47d2be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal563b6827cca32fa1a554dd261a47d2be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal563b6827cca32fa1a554dd261a47d2be)): ?>
<?php $attributes = $__attributesOriginal563b6827cca32fa1a554dd261a47d2be; ?>
<?php unset($__attributesOriginal563b6827cca32fa1a554dd261a47d2be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal563b6827cca32fa1a554dd261a47d2be)): ?>
<?php $component = $__componentOriginal563b6827cca32fa1a554dd261a47d2be; ?>
<?php unset($__componentOriginal563b6827cca32fa1a554dd261a47d2be); ?>
<?php endif; ?>
    </div>
  </main>
  
  <?php echo $__env->make('components.admin-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php if(session()->has('alert')): ?>
    <script>
        const Toast = Swal.mixin({
          toast: true,
          position: "top-end",
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.onmouseenter = Swal.stopTimer;
            toast.onmouseleave = Swal.resumeTimer;
          }
          });
          Toast.fire({
            icon: "<?php echo e(session('alert')); ?>",
            title: "<?php echo e(session('message')); ?>"
          });
    </script>
  <?php endif; ?>

  <script>
    function alert(icon, message) {
      return Swal.fire({
        text: message,
        icon: icon,
        timer: 1500,
        showConfirmButton: false,
        timerProgressBar: true
      })
    }

    // Global delete confirmation
    function modalHapus(id) {
      Swal.fire({
          title: "Kamu yakin?",
          text: "Kamu tidak akan bisa membatalkannya setelah ini!",
          icon: "warning",
          showCancelButton: true,
          confirmButtonColor: "#d33",
          cancelButtonColor: "#a1a1a1",
          confirmButtonText: "Ya, hapus saja!"
      }).then((result) => {
          if (result.isConfirmed) {
              submit(id);
          }
      });
    }

    function submit(id) {
      const form = document.getElementById('form_' + id);
      if (form) form.submit();
    }
  </script>

  <?php if(session()->has('modal_alert')): ?>
    <script>
      Swal.fire({
        text: "<?php echo e(session('message')); ?>",
        icon: "<?php echo e(session('modal_alert')); ?>",
        timer: 1500,
        showConfirmButton: false,
        timerProgressBar: true
      })
    </script>
  <?php endif; ?>
  <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH /home/lossscp/web/dongworld-admin.websiteku.space/public_html/resources/views/layouts/admin-layout.blade.php ENDPATH**/ ?>