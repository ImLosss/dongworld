<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('components.login-head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body class="">
<div class="container position-sticky z-index-sticky top-0">
    <div class="row">
        <div class="col-12">
            <!-- Navbar -->
            
            <!-- End Navbar -->
        </div>
    </div>
</div>
<main class="main-content  mt-0">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo $__env->make('components.login-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if(session()->has('alert')): ?>
    <script>
        const Toast = Swal.mixin({
          toast: true,
          position: "top-end",
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.onmouseenter = Swal.stopTimer;
            toast.onmouseleave = Swal.resumeTimer;
          }
          });
          Toast.fire({
            icon: "<?php echo e(session('alert')); ?>",
            title: "<?php echo e(session('message')); ?>"
          });
    </script>
  <?php endif; ?>
</body>

</html>
<?php /**PATH /home/lossscp/web/dongworld-admin.websiteku.space/public_html/resources/views/layouts/login-layout.blade.php ENDPATH**/ ?>