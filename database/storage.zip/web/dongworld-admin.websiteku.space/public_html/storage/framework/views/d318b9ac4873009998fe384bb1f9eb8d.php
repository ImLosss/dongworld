<?php $__env->startSection('title'); ?>
    - Comment Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="<?php echo e(route('comments.index')); ?>">Comments</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Detail</li>
        </ol>
        <h5 class="font-weight-bolder mb-0">Comment Detail</h5>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-lg-8">
        <div class="card mb-4">
            <div class="card-header pb-0 px-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">Komentar</h6>
                    <span class="text-xs text-secondary"><?php echo e($comment->created_at?->format('d M Y H:i')); ?></span>
                </div>
            </div>
            <div class="card-body pt-3">
                <div class="d-flex align-items-center mb-2">
                    <h6 class="mb-0 me-2"><?php echo e($comment->name); ?></h6>
                    <?php if($comment->is_admin): ?>
                        <span class="badge badge-sm bg-gradient-dark">Admin</span>
                    <?php endif; ?>
                </div>
                <p class="text-sm mb-0"><?php echo e($comment->content); ?></p>
                <hr class="horizontal dark my-4">
                <div class="row text-sm">
                    <div class="col-md-6">
                        <div class="mb-2"><strong>Series:</strong> <?php echo e(optional($comment->episode->series)->name ?? (optional($comment->series)->name ?? '-')); ?></div>
                        <div><strong>Episode:</strong> <?php echo e(optional($comment->episode)->episode_number ?? '-'); ?></div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-2"><strong>Series ID:</strong> <?php echo e(optional($comment->episode->series)->id ?? (optional($comment->series)->id ?? '-')); ?></div>
                        <div><strong>Episode ID:</strong> <?php echo e($comment->episode_id ?? '-'); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header pb-0 px-3">
                <h6 class="mb-0">Balas Komentar</h6>
            </div>
            <div class="card-body pt-3">
                <form action="<?php echo e(route('comments.reply', $comment->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group has-validation">
                        <label class="form-control-label">Isi Balasan</label>
                        <textarea class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger rounded-3 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="content" rows="4" placeholder="Tulis balasan..." autofocus><?php echo e(old('content')); ?></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="text-xs text-secondary mt-2 mb-0">Balasan akan diawali otomatis dengan <strong>{{ $comment->name }}</strong>.</p>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn bg-gradient-dark btn-md">Kirim Balasan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-12 col-lg-4">
        <div class="card mb-4">
            <div class="card-header pb-0 px-3">
                <h6 class="mb-0">Komentar Terkait</h6>
            </div>
            <div class="card-body pt-3">
                <?php $__empty_1 = true; $__currentLoopData = $relatedComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span class="text-sm font-weight-bold"><?php echo e($rel->name); ?></span>
                            <span class="text-xs text-secondary"><?php echo e($rel->created_at?->format('d M')); ?></span>
                        </div>
                        <div class="text-sm text-secondary" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                            <?php echo e($rel->content); ?>

                        </div>
                    </div>
                    <hr class="horizontal dark my-2">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-secondary mb-0">Belum ada komentar terkait.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/lossscp/web/dongworld-admin.websiteku.space/public_html/resources/views/admin/comment/show.blade.php ENDPATH**/ ?>